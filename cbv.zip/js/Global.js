﻿// this is for the Global variables //
var vtranslistcnt = 0;
var numofrows = 0;
var reccounts = 0;
var vsearchstring = "";
var vtelstr3 = "";
var vtelstrcom1="";
var vtelstrcom2="";
var vtelstrcom3 = "";
var vtelephonestr = "";
var vconfirmed = "";
var vgranted = "";
var vcarsaving = "";
var v_counter = 0;
var v_mouseclick = "";
var transactstr = "";
